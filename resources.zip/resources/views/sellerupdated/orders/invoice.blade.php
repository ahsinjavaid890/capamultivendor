<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<title>OBEN | Order ID {{ $id }}</title>

		<!-- Favicon -->
		<link rel="icon" href="./images/favicon.png" type="image/x-icon" />

		<!-- Invoice styling -->
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				text-align: center;
				color: #777;
			}

			body h1 {
				font-weight: 300;
				margin-bottom: 0px;
				padding-bottom: 0px;
				color: #000;
			}

			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style: italic;
				color: #555;
			}

			body a {
				color: #06f;
			}

			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
				border-collapse: collapse;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}
		</style>
	</head>

	<body>
		<div class="invoice-box">
			<table>
				<tr class="top">
					<td colspan="2">
						<table>
							<tr>
								<td class="title">
									<img src="{{asset('public/seller/assets/img/oben-01__logo.png')}}" alt="Company logo" style="width: 100%; max-width: 300px" />
								</td>

								<td>
									Order ID #: {{ $id }}<br />
									Order Date: {{ date('d M Y', strtotime($created_at)) }}<br />
								</td>
							</tr>
						</table>
					</td>
				</tr>

				<tr class="information">
					<td colspan="2">
						<table>
							<tr>
								<td>
									@php 
										$mainorder = DB::table('orders')->where('id' , $id)->get()->first();
										$orderdetails = DB::table('orderdetails')->where('order_id' , $id)->get();
									@endphp

									@if($mainorder->addres_id)

									<br>
									<h3>{{ $mainorder->address }}</h3>
									<br>
									{{ $mainorder->fname }}<br>
									<br>
									{{ $mainorder->phonenumber }}<br>
									{{ $mainorder->email }}<br>



									@else

									<h3>{{ $mainorder->address }}</h3>
									<br>
									{{ $mainorder->fname }}<br>
									<br>
									{{ $mainorder->phonenumber }}<br>
									{{ $mainorder->email }}<br>


									@endif
								</td>

								<td>
									<h3>Customer Details</h3>
									<br>

									{{ $mainorder->fname }}<br>
									{{ $mainorder->email }}<br>
									{{ $mainorder->phonenumber }}<br>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="heading">
					<td>Item</td>
					<td>Quantity</td>
					<td>Price</td>
				</tr>
				@php
                    $subtotal = 0;
                    $shippingcost = 0;
                @endphp
				@foreach($orderdetails as $r)
				<tr class="item">
					<td>{{ DB::table('products')->where('id' , $r->product_id)->get()->first()->product_title }} <br>

						@foreach(DB::table('order_variations')->where('orderdetails' , $r->id)->get() as $variation)
						<small style="padding: 5px;border: 1px solid black;background-color: #3978e2; color: white;">{{ $variation->variation_name }}</small>
						@endforeach

					</td>
					<td>{{ $r->quantity }}</td>
					<td>AED {{ $r->price }}</td>
				</tr>
				@php
                    $subtotal += $r->price*$r->quantity;
                @endphp
				@endforeach
				<tr class="heading">
					<td>Subtotal</td>
					<td></td>
					<td>AED {{$orderdetails->sum('price')}}</td>
				</tr>
				<?php 
                $total = $subtotal;
                ?>
				<tr class="heading">
					<td>Grand Total</td>
					<td></td>
					<td>AED {{ number_format((float)$total, 2, '.', '') }}</td>
				</tr>
			</table>
		</div>
	</body>
</html>
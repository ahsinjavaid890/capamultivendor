<tr>
    <td align="left" style="font-size:0px;padding:10px 25px;word-break:break-word;">
        <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:14px;line-height:20px;text-align:left;color:white;">
            Best regards,<br><br> Csaba Kissi<br>Elerion ltd., CEO and Founder<br>
            <a href="{{ url('') }}" style="color:#2F67F6">{{ url('') }}</a>
        </div>
    </td>
</tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<div style="Margin:0px auto;max-width:600px;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
        <tbody>
            <tr>
                <td style="direction:ltr;font-size:0px;padding:20px 0;text-align:center;vertical-align:top;">

                </td>
            </tr>
        </tbody>
    </table>
</div>
    </div>
</body>

</html>
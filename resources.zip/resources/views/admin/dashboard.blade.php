@extends('admin.layouts.master')
@section('content')
<main>
    
</main>
 @stop              
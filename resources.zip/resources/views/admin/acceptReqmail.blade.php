<p><strong>Request Title :</strong> {{$Request}}</p>
<p><strong>Request Qustion :</strong> {{$questions}}</p>
<p><strong>Request Message :</strong> {{$msg}}</p>
